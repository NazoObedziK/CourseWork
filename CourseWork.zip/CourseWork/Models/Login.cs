﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CourseWorkApp.Models
{
    public class Login
    {
        public int Id { get; set; }
        public string LoginString { get; set; }
        public string Role { get; set; }
    }
}
